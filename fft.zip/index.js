const { IgApiClient, IgCheckpointError }    = require('instagram-private-api');
const { question }                          = require('readline-sync')
const ig                                    = new IgApiClient();
const Bluebird                              = require('bluebird');
const inquirer                              = require('inquirer');
const chalk                                 = require('chalk');
const delay                                 = require('delay');
const { sleep }                             = require('@lifeomic/attempt');
const {instagramIdToUrlSegment, urlSegmentToInstagramId} = require('instagram-id-to-url-segment')

console.log(chalk.yellow(`

███████╗███████╗████████╗
██╔════╝██╔════╝╚══██╔══╝
█████╗  █████╗     ██║   
██╔══╝  ██╔══╝     ██║   
██║     ██║        ██║   
╚═╝     ╚═╝        ╚═╝   
                         

- Script FFT
- Script Created By : AREL TIYAN (SGB TEAM) @07-2020
`))

const u = question(chalk.yellow('+ Username IG : '))
const p = question(chalk.yellow('+ Password IG : '))
const t = question(chalk.yellow('+ Target IG : '))
const d = question(chalk.yellow('+ Text? (text1|text2|text3) : '))
const del = question(chalk.yellow('+ Delay (Menit) : '))
const limdel = question(chalk.yellow('+ Brp user perdelay : '))

ig.state.generateDevice(u);

async function login(IG_USERNAME, IG_PASSWORD) {
    return new Promise ((resolve, reject) => {
    Bluebird.try(async () => {
        const auth = await ig.account.login(IG_USERNAME, IG_PASSWORD);
        resolve(auth)
      }).catch(IgCheckpointError, async () => {
        console.log(ig.state.checkpoint); // Checkpoint info here
        await ig.challenge.auto(true); // Requesting sms-code or click "It was me" button
        console.log(ig.state.checkpoint); // Challenge info here
        console.log(chalk.green('[+++] Check OTP SMS/Email (Jika nomor hp verif cek sms)'))
        const { code } = await inquirer.prompt([
          {
            type: 'input',
            name: 'code',
            message: 'Enter code',
          },
        ]);
        resolve(await ig.challenge.sendSecurityCode(code));
      }).catch(e => console.log(chalk.red('Could not resolve checkpoint:', e, e.stack)));
    });
}

async function getAllItemsFromFeed(feed) {
    let items = [];
    do {
        items = items.concat(await feed.items());
    } while(feed.isMoreAvailable() && items.length < 1000);
    return items;
}

(async () => 
{
    if(!p|!u|!t|!d|!del) return console.log(chalk.red('Check Field!'))
    const auth =  await login(u, p);
    console.log(chalk.green(`[!!!] Getting your following list . . .`))
    var myFollowing = new Array()
    const myID = await ig.user.getIdByUsername(u);
    const getMyFollowing = ig.feed.accountFollowing(myID)
    do {
        myFollowing = myFollowing.concat(await getMyFollowing.items())
    } while(getMyFollowing.isMoreAvailable());

    console.log(chalk.green(`[!!!] Getting @${t} follower list . . .`))
    const id = await ig.user.getIdByUsername(t.replace('@', ''));
    const userFeed = ig.feed.accountFollowers(id)
    do {
        const a = await userFeed.items()
        let g_Pause = parseInt(limdel, 10);
        let post = 0;
        for(i=0;i<a.length;i++)
        {
            if(g_Pause == post) { console.log(chalk.yellow(`\n[---] Delay ${del}m untuk menghindari banned/block.\n`)); await delay(del*60000); g_Pause += parseInt(limdel, 10);}
            if(a[i].is_private != true && a[i].is_verified != true)
            {
                let inList = false;
                myFollowing.map(async function(value, index)
                {
                    if(value.username == a[i].username) inList = true;
                })

                if(inList != true)
                {
                    try {
                        const user_id = a[i].pk
                        const userFeed = ig.feed.user(user_id);
                        const firstPost = await userFeed.items();
                        if(firstPost.length > 0)
                        {
                           try {
                            const text = d.split('|')
                            var raNdText = text[Math.floor(Math.random() * text.length)];
                            var timeNow = new Date();
                            timeNow = `${timeNow.getHours()}:${timeNow.getMinutes()}:${timeNow.getSeconds()}`
                            if(firstPost[0].comments_disabled != true || typeof firstPost[0].comments_disabled == 'undefined')
                            {
                                const publishComment = await ig.media.comment({
                                    mediaId: firstPost[0].pk,
                                    text: raNdText
                                })
                                const publishLike = await ig.media.like({
                                    mediaId: firstPost[0].pk,
                                    moduleInfo: {
                                        module_name: 'profile'
                                    }
                                })
                                const publishFollow = await ig.friendship.create(firstPost[0].user.pk)
                                console.log(chalk.green(`[${timeNow}] >> Follow (${publishFollow && publishFollow.following == true? `Success`: `Gagal`}), Like (${publishLike && publishLike.status =='ok' ? 'Success': 'Gagal'}), Comment (${publishComment && publishComment.status == 'Active'?raNdText:'Gagal'}) User ${chalk.cyan('@'+a[i].username)}`))   
                                post++
                            }else{
                                const thread = ig.entity.directThread([user_id]);
                                await thread.broadcastText(raNdText); 
                                console.log(chalk.green(`[${timeNow}] >> ${chalk.red(`Post Comment Disabled!`)} >> Direct Message (${raNdText}) User ${chalk.cyan('@'+a[i].username)}`)) 
                                post++  
                            }
                           } catch (error) {
                               console.log(error.toString())
                           }
                        }else{
                            console.log(chalk.red(` >> Skipping user ${a[i].username} dikarenakan tidak memiliki Post!`))
                        } 
                    } catch (error) {
                        console.log(error.toString())
                    }
                }else{
                    console.log(chalk.red(` >> Skipping user ${a[i].username} dikarenakan sudah terfollow!`))
                }
            }
            await sleep(2000)
        }
    } while(userFeed.isMoreAvailable());

})()